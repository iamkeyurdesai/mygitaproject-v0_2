  library(tidyverse)  
  mypath <- "./data/import/sadhaksanjeevani/chapters/"
  myfiles <- dir(mypath)
  mytext <- NULL
  
  for (i in 1:length(myfiles)) {
    print(paste("reading", paste0(mypath, myfiles[i])))
    mytemp <- as_tibble(readLines(paste0(mypath, myfiles[i]))) %>%
      mutate(file = myfiles[i])
    mytext <- bind_rows(mytext, mytemp)
  }
  
  mytext <- mytext %>%
    filter(!(value %in% c("", "\t"))) %>%
    mutate(keep = NA)

  mytag_remove <- mytext$value[1]
  mytag_keep <- mytext$value[30]
  
  mykeep <- FALSE
  for (i in 1:nrow(mytext)) {
    if(mytext$value[i] == mytag_remove) mykeep <- FALSE
    if(mytext$value[i] == mytag_keep) mykeep <- TRUE
    mytext$keep[i] <- mykeep
  }
  
  mytext <- mytext %>%
    filter(keep) %>%
    select(-keep) %>%
    mutate(label = str_replace(file, ".txt", "")) %>%
    separate(label, into = c("chapter", "part"), sep = "p")
  
    
  mytag1 <-   "श्लोक :"
  mytext %>% 
    filter(str_detect(value, mytag1)) %>%
    separate(value, into = c("adhyay", "shloak"), remove = FALSE, sep = mytag1)  -> mycount
  
  mycount1 <- NULL
  for( i in 1:nrow(mycount)) {
    mytemp <- mycount %>% slice(i)
    if (str_detect(mytemp$shloak, "-")) {
      mytemp %>% separate(shloak, into = c("first", "last"), sep = "-") -> myix
      myix_count <- as.character(as.numeric(myix$first):as.numeric(myix$last))
      mytemp <- sample_n(mytemp, length(myix_count) , replace = TRUE)
      mytemp$shloak <- myix_count
    }
    mycount1 <- bind_rows(mycount1, mytemp)
  }
  
  
  mycount1 %>% 
    mutate(chapter = as.integer(chapter), shloak = as.integer(shloak)) %>%
    filter(!(shloak == 0)) %>%
    count(chapter) -> mycount2 
    filter(chapter == 11) %>% View()
    
    
  #for chapter 2, 3, 11 there was missing verse 
  # (I forgot to copy verse 24 for chap 2, where is - was forgotten in the android app)  
    
    
  